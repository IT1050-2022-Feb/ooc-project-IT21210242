#pragma once
#include "Rooms.h"
class Reservation
{
protected:
	int resNo;
	char checkin[6];
	char checkout[6];
	int noOfRooms;
	int dineOption;
	int tourGuideOption;

	double price[noOfRooms];

private:
	double total;
	double discount;
	Rooms* rooms;

public:
	Reservation();
	void resdetails(int rno, char cin[], char cout[], int nrooms, int dop, int tgop);
	void displayDetails();
	char getcheckIn();
	char getcheckOut();
	int getnoOfRooms();
	int getdineOption();
	int gettourGuideOption();
	double calculateTotal();
	~Reservation();
};

