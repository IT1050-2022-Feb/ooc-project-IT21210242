#include "user.h"
#include <iostream>
using namespace std;

void user::searchHotels()
{
	int id;
	cout << "Enter room ID: ";
	cin >> id;
	
	rooms.GetRoomInfo(id);
}

void user::searchTables()
{
	int id;
	cout << "Enter table ID: ";
	cin >> id;

	tables.tableStatus(id);
}

void user::searchTourGuides()
{
	int id;
	cout << "Enter Tour Guide ID: ";
	cin >> id;

	tourguide.displayGuideInfo(id);
}
