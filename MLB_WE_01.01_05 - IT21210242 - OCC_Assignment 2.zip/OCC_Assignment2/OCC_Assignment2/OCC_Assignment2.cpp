#include <iostream>
#include <cstring>
#include "user.h"
#include "Reservation.h"
#include "Hotel.h";
#include "Rooms.h";
#include "TourGuide.h";
#include "RegisteredUser.h"
#include "payment.h"
#include "report.h"
#include "table.h"
#include "systemManager.h"
#include "systemAdmin.h"
#define SIZE
using namespace std;

int main()
{
    RegisteredUser* user1;

    user1 = new RegisteredUser();

    delete user1;

    systemAdmin ad1;
    systemManager man1;
    Hotel* hotel1;
    hotel1 = new hotel();
    payment* p;
    p = new payment();
    report* r1;
    r1 = new report(p);


    delete hotel1;
    delete p;
    delete r1;

    Hotel* Hotel1;
    Hotel1 = new Hotel();

    TourGuide* Guide1;
    Guide1 = new TourGuide();

    delete Hotel1;
    delete Guide1;

    Reservation* Res1;

    Res1 = new Reservation();
    delete Res1;

    Payment* pay;
    Refund* fund;

    pay = new Payment();
    fund = new Refund();

    delete pay;
    delete fund;

    return 0;
}




