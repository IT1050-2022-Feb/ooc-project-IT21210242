#include "Reservation.h"
#include <cstring>

Reservation::Reservation()
{
	resNo = 0;
	strcpy_s(checkin, "");
	strcpy_s(checkout, "");
	noOfRooms = 0;
	dineOption = 0;
	tourGuideOption = 0;
}

void Reservation::resdetails(int rno, char cin[], char cout[], int nrooms, int dop, int tgop)
{
	resNo = rno;
	strcpy_s(checkin, cin);
	strcpy_s(checkout, cout);
	noOfRooms = nrooms;
	dineOption = dop;
	tourGuideOption = tgop;
	rooms = new Rooms[nrooms];
	noOfRooms = nrooms;
}

void Reservation::displayDetails()
{
	int i = 0;

	for (i = 0; i < noOfRooms; i++)
	{
		price[i] = Rooms[i].setPrice(price);
	}

	cout << "Reservation: " << endl << "Reservation Number: " << resNo << endl;
	if (noOfRooms != 0) cout << "No of Rooms: " << noOfRooms << endl << "Check in time: " << checkin << endl << "Check out time: " << checkout << endl;
	else if (dineOption != 0) cout << "Dine in Option: " << dineOption << endl;
	else if (tourGuideOption != 0) cout << "Tour Guide Options: " << tourGuideOption << endl;
}

char Reservation::getcheckIn()
{
	return checkIn[6];
}

char Reservation::getcheckOut()
{
	return checkOut[6];
}

int Reservation::getnoOfRooms()
{
	return noOfRooms;
}

int Reservation::getdineOption()
{
	return dineOption;
}

int Reservation::gettourGuideOption()
{
	return tourGuideOption;
}

double Reservation::calculateTotal()
{
	double total = 0;
	int i;

	for (i = 0; i < noOfRooms; i++)
	{
		total += price[i];
	}
	return total;
}

Reservation::~Reservation()
{
	cout << "Objected deleted";
}
