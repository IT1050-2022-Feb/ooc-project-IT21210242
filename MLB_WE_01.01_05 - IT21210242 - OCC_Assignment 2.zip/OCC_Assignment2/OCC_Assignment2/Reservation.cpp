#include <iostream.h>
#include <string>

class Payment {
private:
	int paymentId;
	string paymentMethod;
	double paymentAmount;

public:
	Payment();
	float getTotalCost();
	string getPaymentMethod();
	displayPaymentDetails();
	~Payment();
};

class Refund {
private:
	string refundPeriod;

public:
	Refund();
	int getPaymentID();
	float getTotalCost();
	checkDueDate();
	~Refund();
};