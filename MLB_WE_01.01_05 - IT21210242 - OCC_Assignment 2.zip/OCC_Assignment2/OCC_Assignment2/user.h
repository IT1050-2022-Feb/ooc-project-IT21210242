#pragma once
#include "Rooms.h"
#include "Tables.h"
#include "Tourguide.h"

class user
{
private:
	Rooms* rooms;
	Tables* tables;
	TourGuide* tourguide;

public:
	void searchHotels();
	void searchTables();
	void searchTourGuides();
};
